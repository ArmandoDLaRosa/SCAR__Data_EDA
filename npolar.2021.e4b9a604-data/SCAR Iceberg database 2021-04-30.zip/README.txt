The SCAR International Iceberg database.
Updated 30.04.2021

This archive containes the complete SCAR International Iceberg database from the Norwegian Polar Institute (Norsk Polarinstitutt, NPI) and the Australian Antarctic Division (AAD). For compatibility reasons, the database has been devided into three separat CSV data files. Please read attached documentation file for a complete documentation of the dataset.

NPI_Iceberg_database_1977-2010_version_2020-11-30.csv   (24807 records)
AAD_Iceberg_database_1979-1984_version_2021-04-29.csv   (970 records)
AAD_Iceberg_database_1984-2011_version_2021-04-29.csv   (8061 records)
SCAR Iceberg database - 2021-04-30.docx


